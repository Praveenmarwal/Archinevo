<?php
// Simple config file for contacts viewer
// Change the TOKEN to a secure random string before using in production.
define('CONTACTS_VIEW_TOKEN', 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6');
//http://localhost/arkitektur/contacts_list.php?token=a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6